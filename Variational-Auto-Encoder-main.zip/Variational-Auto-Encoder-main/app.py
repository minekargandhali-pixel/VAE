from flask import Flask, render_template, request, jsonify
import tensorflow as tf
import numpy as np
import io
import base64
from PIL import Image
import os

app = Flask(__name__)

# ============================================================
# MODEL PATHS
# ============================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

ENCODER_PATH = os.path.join(
    BASE_DIR,
    "models",
    "vae_encoder.keras"
)

DECODER_PATH = os.path.join(
    BASE_DIR,
    "models",
    "vae_decoder.keras"
)

# ============================================================
# LOAD VAE DECODER
# ============================================================

try:

    decoder = tf.keras.models.load_model(
        DECODER_PATH,
        compile=False
    )

    print("Decoder loaded successfully.")

except Exception as e:

    print("Error loading decoder:")
    print(e)

    decoder = None


# ============================================================
# HOME PAGE
# ============================================================

@app.route("/")
def index():

    return render_template("index.html")


# ============================================================
# GENERATE IMAGE
# ============================================================

@app.route("/generate", methods=["POST"])
def generate():

    try:

        # ----------------------------------------------------
        # Get JSON data from frontend
        # ----------------------------------------------------

        data = request.get_json()

        z1 = float(data.get("z1", 0))
        z2 = float(data.get("z2", 0))

        # ----------------------------------------------------
        # Limit latent values
        # ----------------------------------------------------

        z1 = np.clip(z1, -3, 3)
        z2 = np.clip(z2, -3, 3)

        # ----------------------------------------------------
        # Create latent vector
        # ----------------------------------------------------

        latent_vector = np.array(
            [[z1, z2]],
            dtype=np.float32
        )

        # ----------------------------------------------------
        # Generate MNIST image
        # ----------------------------------------------------

        if decoder is None:

            return jsonify({
                "success": False,
                "error": "Decoder model could not be loaded."
            })

        generated = decoder.predict(
            latent_vector,
            verbose=0
        )

        # ----------------------------------------------------
        # Handle model output
        # ----------------------------------------------------

        generated = np.asarray(generated)

        # Remove batch dimension

        image = generated[0]

        # ----------------------------------------------------
        # Convert image to 0-255
        # ----------------------------------------------------

        image = np.squeeze(image)

        image = np.clip(
            image,
            0,
            1
        )

        image = (
            image * 255
        ).astype(np.uint8)

        # ----------------------------------------------------
        # Convert to PIL image
        # ----------------------------------------------------

        pil_image = Image.fromarray(
            image,
            mode="L"
        )

        # ----------------------------------------------------
        # Resize for better display
        # ----------------------------------------------------

        pil_image = pil_image.resize(
            (280, 280),
            Image.Resampling.NEAREST
        )

        # ----------------------------------------------------
        # Convert image to PNG
        # ----------------------------------------------------

        buffer = io.BytesIO()

        pil_image.save(
            buffer,
            format="PNG"
        )

        buffer.seek(0)

        image_base64 = base64.b64encode(
            buffer.getvalue()
        ).decode("utf-8")

        # ----------------------------------------------------
        # Return response
        # ----------------------------------------------------

        return jsonify({

            "success": True,

            "image": image_base64,

            "z1": float(z1),

            "z2": float(z2)

        })

    except Exception as e:

        print("Generation error:")
        print(e)

        return jsonify({

            "success": False,

            "error": str(e)

        })


# ============================================================
# RUN FLASK
# ============================================================

if __name__ == "__main__":

    app.run(
        debug=True,
        host="127.0.0.1",
        port=5000
    )